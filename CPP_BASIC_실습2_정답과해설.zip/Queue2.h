#ifndef QUEUE2_H
#define QUEUE2_H

// Queue2.h

class Queue
{

public:
	Queue(int sz = 20);
	~Queue();
	bool isempty() const;
	bool isfull() const;
	void push(int v);
	int front() const;
	void pop();

	Queue(const Queue& q); // ���� ������

private:
	int* buffer;
	int size;
	int first;
	int last;
};

#endif // QUEUE2_H