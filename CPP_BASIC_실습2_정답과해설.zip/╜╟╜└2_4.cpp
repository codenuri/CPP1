#include <iostream>
#include "QueueT.h" // Queue�� ���ø� ����
using namespace std;


int main()
{
	Queue<int> q;

	q.push(10);
	q.push(20);
	q.push(30);

	cout << q.front() << endl;
	q.pop();
	cout << q.front() << endl;
	q.pop();
	cout << q.front() << endl;
}