#ifndef QUEUE3_H
#define QUEUE3_H

// Queue3.h

class Queue
{

public:
	Queue(int sz = 20);
	~Queue();
	bool isempty() const;
	bool isfull() const;
	void push(int v);
	int front() const;
	void pop();

	Queue(const Queue& q);

	// static ��� �Լ��� static ��� data�߰�.
	static int getCount();
private:
	static int cnt;

	int* buffer;
	int size;
	int first;
	int last;
};

#endif // QUEUE3_H