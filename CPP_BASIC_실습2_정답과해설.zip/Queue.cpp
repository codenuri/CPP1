// Queue.cpp
#include "Queue.h"

Queue::Queue(int sz)
	: size(sz), first(0), last(0) {
	buffer = new int[sz];
}
Queue::~Queue() {
	delete[] buffer;
}

bool Queue::isempty() const {
	return first == last;
}

bool Queue::isfull() const {
	return (first + 1) % size == last;
}

void Queue::push(int v)
{
	if (isfull()) return;

	buffer[first++] = v;

	if (first == size) first = 0;
}

int Queue::front() const
{
	return buffer[last];
}
void Queue::pop()
{
	if (isempty())
		return;
	++last;
	if (last == size)
		last = 0;
}